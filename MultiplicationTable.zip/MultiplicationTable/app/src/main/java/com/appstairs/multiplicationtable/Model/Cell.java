package com.appstairs.multiplicationtable.Model;

import android.graphics.Point;

public class Cell extends Point {
//TODO This class is not used meantime. It was created as an infrastructure for future use if the developer decides he needs more uses.
//TODO If so, then add here a constructor + getters (+ setters)
}