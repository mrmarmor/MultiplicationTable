package com.appstairs.multiplicationtable;

public @interface Base {
    int DECIMAL = 10,
        BINARY = 2,
        HEX = 16;
}
